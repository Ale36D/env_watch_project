#include "get_bt_value.h"
#include "bf0_hal.h"
#include "drv_io.h"
#include <rtthread.h>
#include <rtdevice.h>
#include "battery_calculator.h"

#define LOG_TAG "battery"
#include "log.h"

/* ==================== 电池检测配置 ==================== */

/*
 * 黄山派 PA_34 连接充电芯片(AW23001)的 STAT 引脚:
 *   低电平 = 正在充电
 *   高电平 = 未充电 (充满或未接电源)
 */
#define CHARGE_STAT_PIN 44

/*
 * VBAT 电压范围 (单芯锂电池):
 *   4.2V = 100%  (充满)
 *   3.7V = 50%   (标称)
 *   3.4V = 0%    (关机阈值附近)
 */
#define VBAT_MAX_MV 4200
#define VBAT_MIN_MV 3400

/* ==================== 充电状态检测 ==================== */

/**
 * 检测是否正在充电
 * PA_34 = LOW → 充电中
 * PA_34 = HIGH → 未充电
 */
static bool battery_is_charging(void)
{
    return (rt_pin_read(CHARGE_STAT_PIN) == PIN_LOW);
}

/**
 * 获取电池完整信息
 */
battery_calculator_t battery_calc;
uint8_t battery_get_info()
{
    // 2. 读取ADC电压值
    rt_device_t battery_device = rt_device_find("bat1");
    rt_adc_cmd_read_arg_t read_arg;
    read_arg.channel = 7;
    rt_thread_mdelay(300);
    rt_adc_enable((rt_adc_device_t)battery_device, read_arg.channel);
    rt_uint32_t battery_level = rt_adc_read((rt_adc_device_t)battery_device, read_arg.channel);
    rt_adc_disable((rt_adc_device_t)battery_device, read_arg.channel);

    // 3. 计算电量百分比
    return battery_calculator_get_percent(&battery_calc, battery_level);
}

/**
 * 初始化电池检测 (在 main 里调用一次)
 */
void battery_init(void)
{
    battery_calculator_config_t calc_config = {
        .charging_table = charging_curve_table,
        .charging_table_size = charging_curve_table_size,
        .discharging_table = discharge_curve_table,
        .discharging_table_size = discharge_curve_table_size,
        .charge_filter_threshold = 50,     // 充电时50mV阈值
        .discharge_filter_threshold = 30,  // 放电时30mV阈值
        .filter_count = 3,                 // 需要3次确认
        .secondary_filter_enabled = true,  // 启用二级滤波
        .secondary_filter_weight_pre = 90, // 前电压权重90%
        .secondary_filter_weight_cur = 10  // 当前电压权重10%
    };

    battery_calculator_init(&battery_calc, &calc_config);
}

/* ==================== LVGL 显示集成 ==================== */

/*
 * 在 LVGL 线程里定时调用, 更新顶栏电池图标
 * 建议放在 app_lvgl_process() 里, 每 10 秒读一次
 *
 * 用法示例:
 *
 * static uint32_t last_bat_tick = 0;
 * if (lv_tick_get() - last_bat_tick > 10000) {
 *     last_bat_tick = lv_tick_get();
 *     battery_update_ui(your_battery_label);
 * }
 */
void battery_update_ui(lv_obj_t *lbl, uint8_t value)
{

    char buf[32];
    uint8_t bt_value = value;

    if (!battery_is_charging())
    {
        lv_snprintf(buf, sizeof(buf), LV_SYMBOL_CHARGE);
        lv_obj_set_style_text_color(lbl, lv_color_hex(0xFFEB3B), 0); /* 黄色 */
    }
    else if (bt_value <= 10)
    {
        lv_snprintf(buf, sizeof(buf), LV_SYMBOL_BATTERY_EMPTY);
        lv_obj_set_style_text_color(lbl, lv_color_hex(0xE53935), 0); /* 红色 */
    }
    else if (bt_value <= 30)
    {
        lv_snprintf(buf, sizeof(buf), LV_SYMBOL_BATTERY_1);
        lv_obj_set_style_text_color(lbl, lv_color_hex(0xFB8C00), 0); /* 橙色 */
    }
    else if (bt_value <= 60)
    {
        lv_snprintf(buf, sizeof(buf), LV_SYMBOL_BATTERY_2);
        lv_obj_set_style_text_color(lbl, lv_color_white(), 0);
    }
    else
    {
        lv_snprintf(buf, sizeof(buf), LV_SYMBOL_BATTERY_FULL);
        lv_obj_set_style_text_color(lbl, lv_color_hex(0xFFFFFF), 0);
    }

    lv_label_set_text(lbl, buf);
}